package uz.pdp.jpa_app2;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserCantroller {

}
