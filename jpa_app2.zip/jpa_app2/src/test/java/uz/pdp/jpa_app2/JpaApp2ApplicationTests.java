package uz.pdp.jpa_app2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaApp2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
